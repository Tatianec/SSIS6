package com.example.pages.controller;

import com.example.pages.model.User;
import com.example.pages.service.UserService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class RegistrationController {

    @Autowired
    private UserService userService;

    @GetMapping("/register")
    public String registerForm() {
        return "register";
    }

    @PostMapping("/register")
    public String register(@RequestParam String fullName, @RequestParam String email, 
                           @RequestParam String password, @RequestParam String confirmPassword) {
        if (!password.equals(confirmPassword)) {
            return "register";
        }

        User user = new User();
        user.setUsername(fullName);
        user.setEmail(email);
        try {
            userService.registerUser(user, password); 
            return "redirect:/login";
        } catch (Exception e) {
            return "register";
        }
    }
}
