package com.example.pages.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Lob;
import jakarta.persistence.Table;

@Entity
@Table(name = "users")
public class User {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(name = "username", nullable = false, unique = true)
	private String username;

    @Column(name = "encrypted_password", nullable = false) 
    private String encryptedPassword;

	@Column(name = "email", nullable = false, unique = true)
	private String email;

    @Lob
    @Column(name = "public_key", nullable = false) 
    private String publicKey;

    @Lob
    @Column(name = "private_key", nullable = false) 
    private String privateKey;

	@Column(name = "encryptedAESKey", nullable = false)
	private String encryptedAESKey;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getEncryptedPassword() {
		return encryptedPassword;
	}

	public void setEncryptedPassword(String encryptedPassword) {
		this.encryptedPassword = encryptedPassword;
	}

	public String getPublicKey() {
		return publicKey;
	}

	public void setPublicKey(String publicKey) {
		this.publicKey = publicKey;
	}

	public String getPrivateKey() {
		return privateKey;
	}

	public void setPrivateKey(String privateKey) {
		this.privateKey = privateKey;
	}

	public String getEncryptedAESKey() {
		return encryptedAESKey;
	}

	public void setEncryptedAESKey(String encryptedAESKey) {
		this.encryptedAESKey = encryptedAESKey;
	}

}
