package com.example.pages;

import java.sql.Connection;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class PagesApplication {

	@Autowired
    private DataSource dataSource;

    public static void main(String[] args) {
        SpringApplication.run(PagesApplication.class, args);
    }

    @Bean
    public CommandLineRunner commandLineRunner() {
        return args -> {
            try (Connection conn = dataSource.getConnection()) {
                System.out.println("Conexão bem sucedida: " + conn.getCatalog());
            } catch (Exception e) {
                System.out.println("Erro ao conectar ao banco de dados:");
                e.printStackTrace();
            }
        };
    }
}
