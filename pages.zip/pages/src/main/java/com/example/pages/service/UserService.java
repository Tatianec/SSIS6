package com.example.pages.service;

import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.PrivateKey;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.Base64;

import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.pages.model.User;
import com.example.pages.repository.UserRepository;
import com.example.pages.util.EncryptionUtil;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    public void registerUser(User user, String plainPassword) throws Exception {
        SecretKey aesKey = EncryptionUtil.generateAESKey();
        byte[] encryptedPassword = EncryptionUtil.encryptAES(plainPassword.getBytes(), aesKey);

        KeyPair rsaKeyPair = EncryptionUtil.generateRSAKeyPair();
        byte[] encryptedAESKey = EncryptionUtil.encryptRSA(aesKey.getEncoded(), rsaKeyPair.getPublic());

        user.setEncryptedPassword(Base64.getEncoder().encodeToString(encryptedPassword));
        user.setPublicKey(Base64.getEncoder().encodeToString(rsaKeyPair.getPublic().getEncoded()));
        user.setPrivateKey(Base64.getEncoder().encodeToString(rsaKeyPair.getPrivate().getEncoded()));
        user.setEncryptedAESKey(Base64.getEncoder().encodeToString(encryptedAESKey));

        userRepository.save(user);
    }

    public boolean authenticate(String username, String password) throws Exception {
        User user = userRepository.findByUsername(username).orElse(null);
        if (user == null) {
            return false;
        }

        PrivateKey privateKey = decodePrivateKey(user.getPrivateKey());
        byte[] decryptedAESKey = EncryptionUtil.decryptRSA(Base64.getDecoder().decode(user.getEncryptedAESKey()), privateKey);
        SecretKey originalAESKey = new SecretKeySpec(decryptedAESKey, "AES");

        byte[] decryptedPassword = EncryptionUtil.decryptAES(Base64.getDecoder().decode(user.getEncryptedPassword()), originalAESKey);

        return password.equals(new String(decryptedPassword));
    }

    
    private PrivateKey decodePrivateKey(String base64PrivateKey) throws Exception {
        byte[] decoded = Base64.getDecoder().decode(base64PrivateKey);
        PKCS8EncodedKeySpec keySpec = new PKCS8EncodedKeySpec(decoded);
        KeyFactory keyFactory = KeyFactory.getInstance("RSA", "BC");
        return keyFactory.generatePrivate(keySpec);
    }

}
